from flask import Flask, render_template, request
import pickle
from sklearn.linear_model import LogisticRegression
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')
@app.route('/predict',methods=['POST'])
def predict():
    if request.method == 'POST':
        da1=request.form['a']
        da2=request.form['b']
        da3=request.form['c']
        da4=request.form['d']
        da5=request.form['e']
        da6=request.form['f']
        data=[[float(da1),float(da2),float(da3),float(da4),float(da5),float(da6)]]
        lr=pickle.load(open('weather.pkl', 'rb'))
        prediction = lr.predict(data)[0]
    return render_template('index.html',prediction=prediction)    
        


if __name__ == "__main__":
    app.run()
    
  
    
