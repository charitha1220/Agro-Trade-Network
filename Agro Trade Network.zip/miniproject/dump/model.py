import pandas as pd
import numpy as np
import pickle

data = pd.read_csv("weather.csv")
from sklearn.linear_model import LogisticRegression

x=data.drop(['Formatted Date','Summary','Precip Type','Loud Cover','Pressure (millibars)','Daily Summary'],axis=1)
y=data['Daily Summary']
lr=LogisticRegression(class_weight="balanced")
lr.fit(x,y)
#data.isna().sum()
y_pred=lr.predict(x)
from sklearn.metrics import accuracy_score
accuracy_score(y,y_pred)

#lr.predict([[9.472222,7.388889,0.89,14.1197,251,15.8263]])
with open('weather.pkl','wb') as f:
    pickle.dump(lr,f)
